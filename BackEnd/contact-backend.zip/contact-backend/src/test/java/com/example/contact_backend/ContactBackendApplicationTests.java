package com.example.contact_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
