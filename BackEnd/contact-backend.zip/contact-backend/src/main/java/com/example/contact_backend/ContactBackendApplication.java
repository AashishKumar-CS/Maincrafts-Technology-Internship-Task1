package com.example.contact_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactBackendApplication.class, args);
	}

}
